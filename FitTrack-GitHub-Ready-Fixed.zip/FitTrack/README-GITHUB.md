# FitTrack — Build without Android Studio

## What you need
- A free GitHub account
- A GitHub repository
- This project folder

## Upload
1. Create a new GitHub repository, e.g. `FitTrack`.
2. Upload the **contents of this FitTrack folder** to the repository (not the outer folder).
3. Open the repository's **Actions** tab.
4. Select **Build FitTrack APK**.
5. Click **Run workflow**.
6. Wait for the build to finish.
7. Open the completed workflow run.
8. Under **Artifacts**, download `FitTrack-release-apk`.
9. Unzip it and install the APK on your Android phone.

A normal `push` to the `main` branch also triggers a build automatically.

## Important
This workflow intentionally produces an **unsigned release APK**. Android may show a warning when installing it. For a personal app, that is fine. If the app is later published to Google Play, it should use a proper signing key and Play App Signing.

## Data
The app is designed for local structured data and future database migrations. The manual backup/restore feature should be used to preserve entries across uninstall/reinstall.
