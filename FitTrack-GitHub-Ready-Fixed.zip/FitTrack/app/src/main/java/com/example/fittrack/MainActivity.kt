package com.example.fittrack

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.UUID

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { FitTrackApp() } }
}

enum class Mark { CHECK, CROSS, DASH }
data class Entry(
    val id: String = UUID.randomUUID().toString(), val date: LocalDate, val weight: Double, val waist: Double,
    val breakfast: Mark = Mark.DASH, val lunch: Mark = Mark.DASH, val dinner: Mark = Mark.DASH,
    val water: Mark = Mark.DASH, val protein: Mark = Mark.DASH, val walking: Mark = Mark.DASH,
    val exercise: Mark = Mark.DASH, val nutrition: Mark = Mark.DASH, val grooming: Mark = Mark.DASH,
    val result: Mark = Mark.DASH
)

class FitViewModel : ViewModel() {
    private val _entries = MutableStateFlow<List<Entry>>(emptyList()); val entries: StateFlow<List<Entry>> = _entries.asStateFlow()
    fun save(e: Entry) { _entries.value = (_entries.value.filterNot { it.date == e.date } + e).sortedByDescending { it.date } }
    fun delete(e: Entry) { _entries.value = _entries.value.filterNot { it.id == e.id } }
}

@Composable fun FitTrackApp(vm: FitViewModel = viewModel()) {
    var tab by remember { mutableIntStateOf(0) }; var editing by remember { mutableStateOf<Entry?>(null) }
    MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF222222), background = Color(0xFFF7F7F5))) {
        Scaffold(bottomBar = { NavigationBar { listOf(Icons.Default.Home to "Dashboard", Icons.Default.CalendarMonth to "Entries", Icons.Default.BarChart to "Trends").forEachIndexed { i, p -> NavigationBarItem(selected = tab == i, onClick = { tab=i }, icon={Icon(p.first,null)}, label={Text(p.second)}) } } },
            floatingActionButton = { if (tab == 1) FloatingActionButton(onClick={editing=Entry(date=LocalDate.now(),weight=70.0,waist=34.0)}) { Icon(Icons.Default.Add,"Add") } }) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) { when(tab) { 0 -> Dashboard(vm); 1 -> Entries(vm){editing=it}; else -> Trends(vm) }; editing?.let { AddEntry(it, vm, onClose={editing=null}) } }
        }
    }
}

@Composable fun Dashboard(vm: FitViewModel) { val es by vm.entries.collectAsState(); val latest=es.firstOrNull(); Column(Modifier.fillMaxSize().padding(20.dp)) { Text("FitTrack",fontSize=30.sp,fontWeight=FontWeight.Bold); Text("Your daily consistency, in one place",color=Color.Gray); Spacer(Modifier.height(20.dp)); Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){ Stat("Weight",latest?.let{"%.1f kg".format(it.weight)}?:"—"); Stat("Waist",latest?.let{"%.1f\"".format(it.waist)}?:"—") }; Spacer(Modifier.height(14.dp)); Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(18.dp)){Text("Entries",fontWeight=FontWeight.Bold);Text("${es.size} days recorded",fontSize=26.sp,fontWeight=FontWeight.SemiBold);Text(if(es.isEmpty())"Add your first entry to start your trends." else "Keep building the streak.",color=Color.Gray)}}; Spacer(Modifier.height(14.dp)); if(es.isNotEmpty()) Text("Latest",fontWeight=FontWeight.Bold); es.take(3).forEach{MiniEntry(it)} } }
@Composable fun Stat(t:String,v:String){Card(Modifier.weight(1f),shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(16.dp)){Text(t,color=Color.Gray);Text(v,fontSize=24.sp,fontWeight=FontWeight.Bold)}}}
@Composable fun MiniEntry(e:Entry){Card(Modifier.fillMaxWidth().padding(vertical=4.dp),shape=RoundedCornerShape(14.dp)){Row(Modifier.padding(14.dp).fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Column{Text(e.date.format(DateTimeFormatter.ofPattern("dd MMM yyyy")),fontWeight=FontWeight.Bold);Text("%.1f kg  ·  %.1f\"".format(e.weight,e.waist),color=Color.Gray)};Text(mark(e.result),fontSize=24.sp)}}}

@Composable fun Entries(vm:FitViewModel,onEdit:(Entry)->Unit){val es by vm.entries.collectAsState(); if(es.isEmpty())Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){Text("No entries yet. Tap + to add one.",color=Color.Gray)} else LazyColumn(Modifier.fillMaxSize().padding(16.dp)){items(es){e->EntryCard(e,onEdit)}}}
@Composable fun EntryCard(e:Entry,onEdit:(Entry)->Unit){Card(Modifier.fillMaxWidth().padding(vertical=5.dp).clickable{onEdit(e)},shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(16.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Column{Text(e.date.format(DateTimeFormatter.ofPattern("dd MMM yyyy")),fontSize=18.sp,fontWeight=FontWeight.Bold);Text("%.1f kg  ·  %.1f\"".format(e.weight,e.waist),color=Color.Gray)};Text(mark(e.result),fontSize=25.sp)}};Spacer(Modifier.height(10.dp)); val xs=listOf("B" to e.breakfast,"L" to e.lunch,"D" to e.dinner,"W" to e.water,"P" to e.protein,"Walk" to e.walking,"Ex" to e.exercise,"Nut" to e.nutrition,"G" to e.grooming); Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(7.dp)){xs.forEach{(n,m)->AssistChip(onClick={},label={Text("$n ${mark(m)}")})}}}}
fun mark(m:Mark)=when(m){Mark.CHECK->"✅";Mark.CROSS->"❌";Mark.DASH->"➖"}

@Composable fun AddEntry(seed:Entry,vm:FitViewModel,onClose:()->Unit){var e by remember(seed.id){mutableStateOf(seed)}; AlertDialog(onDismissRequest=onClose,title={Text("${if(vm.entries.value.any{it.id==e.id})"Edit" else "Add"} Entry")},text={Column(Modifier.verticalScroll(rememberScrollState())){Wheel("Weight (kg)",e.weight,30.0,150.0){e=e.copy(weight=it)};Wheel("Waist (inch)",e.waist,20.0,60.0){e=e.copy(waist=it)};Spacer(Modifier.height(8.dp)); listOf("Breakfast" to {m:Mark->e=e.copy(breakfast=m)},"Lunch" to {m:Mark->e=e.copy(lunch=m)},"Dinner" to {m:Mark->e=e.copy(dinner=m)},"Water" to {m:Mark->e=e.copy(water=m)},"Protein" to {m:Mark->e=e.copy(protein=m)},"Walking" to {m:Mark->e=e.copy(walking=m)},"Exercise" to {m:Mark->e=e.copy(exercise=m)},"Nutrition" to {m:Mark->e=e.copy(nutrition=m)},"Grooming" to {m:Mark->e=e.copy(grooming=m)},"Result" to {m:Mark->e=e.copy(result=m)}).forEach{(n,set)->StatusRow(n,when(n){"Breakfast"->e.breakfast;"Lunch"->e.lunch;"Dinner"->e.dinner;"Water"->e.water;"Protein"->e.protein;"Walking"->e.walking;"Exercise"->e.exercise;"Nutrition"->e.nutrition;"Grooming"->e.grooming;else->e.result},set)}}},confirmButton={Button(onClick={vm.save(e);onClose()}){Text("Save Entry")}},dismissButton={TextButton(onClick=onClose){Text("Cancel")}})}

@Composable fun Wheel(label:String,value:Double,min:Double,max:Double,onChange:(Double)->Unit){var text by remember(value){mutableStateOf("%.1f".format(value))}; Column{Text(label,fontWeight=FontWeight.SemiBold);Row(verticalAlignment=Alignment.CenterVertically){Text("▲",Modifier.clickable{onChange((value+0.1).coerceAtMost(max))}.padding(10.dp));Text("$text",Modifier.background(Color.White,RoundedCornerShape(12.dp)).padding(horizontal=24.dp,vertical=12.dp),fontSize=21.sp,fontWeight=FontWeight.Bold);Text("▼",Modifier.clickable{onChange((value-0.1).coerceAtLeast(min))}.padding(10.dp))}}}
@Composable fun StatusRow(name:String,current:Mark,set:(Mark)->Unit){Row(Modifier.fillMaxWidth().padding(vertical=4.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceBetween){Text(name);Row{listOf(Mark.CHECK,Mark.CROSS,Mark.DASH).forEach{m->FilterChip(selected=current==m,onClick={set(m)},label={Text(mark(m))},modifier=Modifier.padding(start=4.dp))}}}}

@Composable fun Trends(vm:FitViewModel){val es by vm.entries.collectAsState();Column(Modifier.fillMaxSize().padding(20.dp)){Text("Trends",fontSize=28.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(15.dp));if(es.size<2)Text("Add at least two entries to see weight and waist trends.",color=Color.Gray) else {Text("Weight trend",fontWeight=FontWeight.Bold);Text(es.reversed().joinToString("  →  "){"%.1f".format(it.weight)+" kg"});Spacer(Modifier.height(20.dp));Text("Waist trend",fontWeight=FontWeight.Bold);Text(es.reversed().joinToString("  →  "){"%.1f".format(it.waist)+"\""});Spacer(Modifier.height(20.dp));Text("Graph canvas is ready for the next iteration.",color=Color.Gray)}}}
